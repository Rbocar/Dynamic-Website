<!DOCTYPE html>
<html>
<head>
<title>My Gaming Products Site</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>

	<?php include('includes/header.inc'); ?>
	<?php include('includes/nav.inc'); ?>
	

<div id="wrapper">

	<?php include('includes/aside.inc'); ?>
	
	<section>
	
	<h2>Mail Sign Up</h2>
	<?php $name = $_POST['name'];
	$email = $_POST['email'];
	$message = $_POST['message'];
	$formcontent="From: $name \n Message: $message";
	$recipient = "emailaddress@here.com";
	$subject = "Contact Form";
	$mailheader = "From: $email \r\n";
	mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
	echo "Thank You!";
	?>
	
	<form action="mail.php" method="POST">
	<p>Name</p> <input type="text" name="name">
	<p>Email</p> <input type="text" name="email">
	<p>Message</p><textarea name="message" rows="6" cols="25"></textarea><br />
	<input type="submit" value="Send"><input type="reset" value="Clear">
	</form>
	
	</section>

</div>

	<?php include('includes/footer.inc'); ?>

</body>
</html>
