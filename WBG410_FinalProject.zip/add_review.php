<?php

mysql_connect("rbocarmy_gameSite", "410rwrt" ,"D3vryUn1vers1ty");
mysql_select_db("reviews");

$name = $_POST["name"];
$review = $_POST["review"];

$review_length = strlen($review);

if($review_length > 500)
{
	header("location: home.php?error=1");
}
else
{
	mysql_query("INSERT INTO reviews VALUES('','$names','$review')");
	header("location: home.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>My Gaming Products Site</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>

	<?php include('includes/header.inc'); ?>
	<?php include('includes/nav.inc'); ?>
	

<div id="wrapper">

	<?php include('includes/aside.inc'); ?>
	
	<section>
	
	<?php include('inlcudes/dbc.php'); ?>
	
	</section>

</div>

	<?php include('includes/footer.inc'); ?>

</body>
</html>
