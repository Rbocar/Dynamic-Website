<!DOCTYPE html>
<html>
<?php
mysql_connect("rbocarmy_gameSite", "410rwrt" ,"D3vryUn1vers1ty");
mysql_select_db("reviews");

$find_reviews = mysql_query("SELECT * FROM reviews");
while($row = mysql_fetch_assoc($find_reviews))
{
	$review_name = $row['name'];
	$review = $row['review'];
	
	echo "$review_name - $review<p>";
}

if(isset($_GET['error']))
{
	echo "<p>500 Character limit";
}

?>
<head>
<title>My Gaming Products Site</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>

	<?php include('includes/header.inc'); ?>
	<?php include('includes/nav.inc'); ?>
	

<div id="wrapper">

	<?php include('includes/aside.inc'); ?>
	
	<section>
	<h2>Reviews</h2>
	<form aciton="add_review.php" method="POST">
		<input type="text" name="name" value="Your name"><br>
		<textarea name="review" cols="50" rows="15">Enter your review</textarea>
		<input type="submit" value="Review">
	</form>
	
	</section>

</div>

	<?php include('includes/footer.inc'); ?>

</body>
</html>
