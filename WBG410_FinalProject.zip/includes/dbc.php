<?php
//*********************************************************
//
//	File: dbc.php
//	Connect Read-only to MySQL database via PHP
//*********************************************************

	$host = "localhost";
	$userName = "rbocarmy_410rdo";
	$passWord = "d3vryun1v3rs1ty";
	$dataBase = "rbocarmy_gameSite";
	
	$con = mysqli_connect($host, $userName, $passWord,$dataBase);
	
	$connect_error = mysqli_connect_error();
	if($connection_error != null){
		echo "<p>Error connecting to database: $connection_error </p>";
	}else{
		//echo "Connected to Read-Only MySQL<br />";
	}
?>